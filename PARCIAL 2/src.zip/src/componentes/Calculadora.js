import React, { useState } from 'react';
import './Calculadora.css';

const Calculadora = () => {
  const [pantalla, setPantalla] = useState(''); 
  const [resultado, setResultado] = useState('');
  const [autor] = useState('Isabella Castañeda Zapata - 2220338'); 

  const agregarNumero = (numero) => {
    setPantalla((prevPantalla) => prevPantalla + numero);
  };

  const agregarOperador = (operador) => {
    const ultimoCaracter = pantalla.slice(-1);
    if (pantalla && !['+', '-', '*', '/'].includes(ultimoCaracter)) {
      setPantalla((prevPantalla) => prevPantalla + ` ${operador} `);
    }
  };

  const ejecutarCalculo = () => {
    if (pantalla.trim()) {
      try {
        const total = eval(pantalla.replace(/[^\d+\-*/.]/g, '')); 
        setResultado(total);
        setPantalla(''); 
      } catch (error) {
        setResultado('Error');
      }
    }
  };

  const reiniciar = () => {
    setPantalla('');
    setResultado('');
  };

  return (
    <div className="calculadora">
      <div className="pantalla">{pantalla || resultado}</div>
      <div className="botones">
        {}
        {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((numero) => (
          <button key={numero} className="boton-numero" onClick={() => agregarNumero(numero.toString())}>
            {numero}
          </button>
        ))}
        <button className="boton-numero" onClick={() => agregarNumero('0')}>0</button>
        
        {}
        {['+', '-', '*', '/'].map((operador) => (
          <button key={operador} className="boton-operacion" onClick={() => agregarOperador(operador)}>
            {operador}
          </button>
        ))}

        {}
        <button className="boton-reset" onClick={reiniciar}>C</button>
        <button className="boton-operacion" onClick={ejecutarCalculo}>=</button>
      </div>
      <div className="info">
        {autor}
      </div>
    </div>
  );
};

export default Calculadora;
