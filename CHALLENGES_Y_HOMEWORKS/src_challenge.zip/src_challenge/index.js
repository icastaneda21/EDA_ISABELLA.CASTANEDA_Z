import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import FirstApp from './FirtsApp';

ReactDOM.createRoot(document.getElementById('root')).render(
<React.StrictMode>
<FirstApp title="My First App" />
</React.StrictMode>
)