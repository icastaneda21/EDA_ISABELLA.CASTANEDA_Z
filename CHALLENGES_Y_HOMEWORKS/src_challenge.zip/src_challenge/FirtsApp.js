import React from 'react';

const title = 'First App';
const FirstApp = () => {
  return (
    <div>
      <h1>{ title }</h1>
      <span>10</span>
    </div>
  );
}

export default FirstApp

import PropTypes from 'prop-types';
const FirstApp = ({ title, sum } ) => { return 
}
<h1> { title } </h1> <span> { sum } </span>
</>
FirstApp.propTypes = {
}
title: PropTypes.string.isRequired, sum: PropTypes.number.isRequired
FirstApp.defaultProps = {
}
title: 'No hay titulo', sum: 300
export default FirstApp

