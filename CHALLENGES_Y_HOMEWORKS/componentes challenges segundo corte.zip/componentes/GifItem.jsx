import React from 'react';

const GifItem = ({ title, url }) => {
  return (
    <div className="gif-item">
      <h4>{title}</h4> {/* Imprime el título */}
      <img src={url} alt={title} /> {/* Muestra la imagen */}
    </div>
  );
};

export default GifItem;
