import React, { useState, useEffect } from 'react';
import { getGifs } from './path/to/getGifs'; 
import GifItem from './GifItem'; 

const GifGrid = ({ category }) => {
  
  const [images, setImages] = useState([]);

 
  const fetchGifs = async () => {
    const newGifs = await getGifs(category); 
    console.log(newGifs); 
    setImages(newGifs); 
  };

  
  useEffect(() => {
    fetchGifs();
  }, [category]);

  return (
    <div className="gif-grid">
      {}
      <h3>{category}</h3>
      <div className="gif-list">
        {}
        {images.map((gif) => (
          <GifItem key={gif.id} {...gif} /> 
        ))}
      </div>
    </div>
  );
};

export default GifGrid;
